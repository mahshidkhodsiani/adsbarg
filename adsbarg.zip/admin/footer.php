<footer>
    <div id="experts">
    <div id="6d9f64b7-09ab-495a-bf6d-8cb2b8c0e098" class="d-none expertBox bg-white shadow px-2 py-3 w-100 rounded-3 mb-3">
        <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <div>
            <img decoding="async" src="" alt="شریفی - کارشناس گوگل ادز" class="me-2">
            </div>
            <div>
            <p class="fw-bold fs-4 mb-0 text-primary">زهرا شریفی</p>
            <p class="fw-normal fs-3 mb-0">داخلی ۱۰۷</p>
            </div>
        </div>
        <div class="d-flex">
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="tel:09056622606">
            <i class="fs-5 ti ti-phone"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://api.whatsapp.com/send?phone=989056622606&amp;text=%D8%B3%D9%84%D8%A7%D9%85.%20%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87%20%D8%AF%D8%B1%20%D8%B2%D9%85%DB%8C%D9%86%D9%87%20%D8%AA%D8%A8%D9%84%DB%8C%D8%BA%D8%A7%D8%AA%20%DA%AF%D9%88%DA%AF%D9%84%20%D8%AA%D9%85%D8%A7%D8%B3%20%DA%AF%D8%B1%D9%81%D8%AA%D9%85">
            <i class="fs-5 ti ti-brand-whatsapp"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://t.me/gads_support_7">
            <i class="fs-5 ti ti-brand-telegram"></i>
            </a>
        </div>
        </div>
    </div>

    <!-- <div id="a0c692e5-8e23-43ca-a171-145a2f0f9f0c" class="expertBox bg-white shadow px-2 py-3 w-100 rounded-3 mb-3">
        <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <div>
            <img decoding="async" src="#" alt="تهرانی - کارشناس گوگل ادز" class="me-2">
            </div>
            <div>
            <p class="fw-bold fs-4 mb-0 text-primary">نفس تهرانی</p>
            <p class="fw-normal fs-3 mb-0">داخلی ۱۰۶</p>
            </div>
        </div>
        <div class="d-flex">
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="tel:09026015384">
            <i class="fs-5 ti ti-phone"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://api.whatsapp.com/send?phone=989026015384&amp;text=%D8%B3%D9%84%D8%A7%D9%85.%20%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87%20%D8%AF%D8%B1%20%D8%B2%D9%85%DB%8C%D9%86%D9%87%20%D8%AA%D8%A8%D9%84%DB%8C%D8%BA%D8%A7%D8%AA%20%DA%AF%D9%88%DA%AF%D9%84%20%D8%AA%D9%85%D8%A7%D8%B3%20%DA%AF%D8%B1%D9%81%D8%AA%D9%85">
            <i class="fs-5 ti ti-brand-whatsapp"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://t.me/gads_support_6">
            <i class="fs-5 ti ti-brand-telegram"></i>
            </a>
        </div>
        </div>
    </div> -->

    <div id="fdf40a35-a079-40f1-bbae-5f4e6fcf175d" class="d-none expertBox bg-white shadow px-2 py-3 w-100 rounded-3 mb-3">
        <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <div>
            <img decoding="async" src="#" alt="کیا - کارشناس گوگل ادز" class="me-2">
            </div>
            <div>
            <p class="fw-bold fs-4 mb-0 text-primary">شیوا کیا</p>
            <p class="fw-normal fs-3 mb-0">داخلی ۱۰۴</p>
            </div>
        </div>
        <div class="d-flex">
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="tel:09396410499">
            <i class="fs-5 ti ti-phone"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://api.whatsapp.com/send?phone=989396410499&amp;text=%D8%B3%D9%84%D8%A7%D9%85.%20%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87%20%D8%AF%D8%B1%20%D8%B2%D9%85%DB%8C%D9%86%D9%87%20%D8%AA%D8%A8%D9%84%DB%8C%D8%BA%D8%A7%D8%AA%20%DA%AF%D9%88%DA%AF%D9%84%20%D8%AA%D9%85%D8%A7%D8%B3%20%DA%AF%D8%B1%D9%81%D8%AA%D9%85">
            <i class="fs-5 ti ti-brand-whatsapp"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://t.me/g_ads_support_4">
            <i class="fs-5 ti ti-brand-telegram"></i>
            </a>
        </div>
        </div>
    </div>
    <div id="8131b214-bc23-4460-baca-408fa025e32e" class="d-none expertBox bg-white shadow px-2 py-3 w-100 rounded-3 mb-3">
        <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <div>
            <img decoding="async" src="#" alt="سیمین پور - کارشناس گوگل ادز" class="me-2">
            </div>
            <div>
            <p class="fw-bold fs-4 mb-0 text-primary">ملیحه سیمین پور</p>
            <p class="fw-normal fs-3 mb-0">‌داخلی ۱۰۵</p>
            </div>
        </div>
        <div class="d-flex ms-3">
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="tel:09374779838">
            <i class="fs-5 ti ti-phone"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://api.whatsapp.com/send?phone=989374779838&amp;text=%D8%B3%D9%84%D8%A7%D9%85.%20%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87%20%D8%AF%D8%B1%20%D8%B2%D9%85%DB%8C%D9%86%D9%87%20%D8%AA%D8%A8%D9%84%DB%8C%D8%BA%D8%A7%D8%AA%20%DA%AF%D9%88%DA%AF%D9%84%20%D8%AA%D9%85%D8%A7%D8%B3%20%DA%AF%D8%B1%D9%81%D8%AA%D9%85">
            <i class="fs-5 ti ti-brand-whatsapp"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://t.me/gads_support_5">
            <i class="fs-5 ti ti-brand-telegram"></i>
            </a>
        </div>
        </div>
    </div>
    <div id="ff314126-9661-4161-8b3c-043564045adc" class="d-none expertBox bg-white shadow px-2 py-3 w-100 rounded-3 mb-3">
        <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <div>
            <img decoding="async" src="#" alt="بنکدار - کارشناس گوگل ادز" class="me-2">
            </div>
            <div>
            <p class="fw-bold fs-4 mb-0 text-primary">نیکا بنکدار</p>
            <p class="fw-normal fs-3 mb-0">داخلی ۱۰۸</p>
            </div>
        </div>
        <div class="d-flex">
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="tel:09056633606">
            <i class="fs-5 ti ti-phone"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://api.whatsapp.com/send?phone=989056633606&amp;text=%D8%B3%D9%84%D8%A7%D9%85.%20%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87%20%D8%AF%D8%B1%20%D8%B2%D9%85%DB%8C%D9%86%D9%87%20%D8%AA%D8%A8%D9%84%DB%8C%D8%BA%D8%A7%D8%AA%20%DA%AF%D9%88%DA%AF%D9%84%20%D8%AA%D9%85%D8%A7%D8%B3%20%DA%AF%D8%B1%D9%81%D8%AA%D9%85">
            <i class="fs-5 ti ti-brand-whatsapp"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://t.me/g_ads_support_8">
            <i class="fs-5 ti ti-brand-telegram"></i>
            </a>
        </div>
        </div>
    </div>
    <div id="b240d8da-e2ee-45d8-9006-32e96ba8dcec" class="d-none expertBox bg-white shadow px-2 py-3 w-100 rounded-3 mb-3">
        <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex">
            <div>
            <img decoding="async" src="#" alt="محمدی - کارشناس گوگل ادز" class="me-2">
            </div>
            <div>
            <p class="fw-bold fs-4 mb-0 text-primary">فرهاد محمدی</p>
            <p class="fw-normal fs-3 mb-0">داخلی ۱۰۲</p>
            </div>
        </div>
        <div class="d-flex ms-3">
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="tel:09308727143">
            <i class="fs-5 ti ti-phone"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://api.whatsapp.com/send?phone=989308727143&amp;text=%D8%B3%D9%84%D8%A7%D9%85.%20%D8%A8%D8%B1%D8%A7%DB%8C%20%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87%20%D8%AF%D8%B1%20%D8%B2%D9%85%DB%8C%D9%86%D9%87%20%D8%AA%D8%A8%D9%84%DB%8C%D8%BA%D8%A7%D8%AA%20%DA%AF%D9%88%DA%AF%D9%84%20%D8%AA%D9%85%D8%A7%D8%B3%20%DA%AF%D8%B1%D9%81%D8%AA%D9%85">
            <i class="fs-5 ti ti-brand-whatsapp"></i>
            </a>
            <a class="btn btn-primary btn-circle btn-sm d-inline-flex align-items-center justify-content-center me-1" href="https://t.me/gads_support_2">
            <i class="fs-5 ti ti-brand-telegram"></i>
            </a>
        </div>
        </div>
    </div>
    </div>
</footer>